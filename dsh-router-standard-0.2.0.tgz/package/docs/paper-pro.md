# Interface-Aware Routing for DeepSeek V4 Pro

**Measured three-band structure, competition-trap avoidance, and a task-aware
preset (router-pro) that selects the RL interface for maintenance and the
doer interface for greenfield work**

*Community research draft · 2026-08-16 · All measurements via the official
DeepSeek API (`api.deepseek.com`), `thinking.enabled`,
`reasoning_effort=max`, fixed micro-task / black-hole build task / repair
task batteries. Companion: `pro-test.md` (data page), `INVERSE-REPORT.md`
(flash+pro full inversion), `router-pro/` (the preset).*

---

## Abstract

We report the measured behavior-band structure of DeepSeek V4 Pro along the
persona-injection axis and derive a task-aware routing preset from it. A
continuous injection axis (RL training sentence + fraction of a doer
persona, 21 points coarse + 0.01-step dense scan, n=10) reveals a sharp
**three-band structure**: an RL-interface band [0, 0.025] (ψ₁ = 0.925),
a **competition trap** [0.025, 0.455] (ψ₁ = 0.464, per-point 0–80% variance),
and a doer band [0.455, 1] (ψ₁ = 0.073); transition center xc = 0.192
(bootstrap CI [0.151, 0.229]). A 140-request discrimination matrix over the
competition band shows **9/12 probe points anti-route** (maintenance fixed
by the spec anchor, greenfield pulled *more* plan-collective, −2.0..−10.6)
and zero self-routing points. Long-chain sessions (9 chains × 3 stages)
show path commitment suppresses in-chain lean, and the Okay token trigger
(Mid-Think) is Flash-specific, neutral on Pro. We release **router-pro**, a
preset that classifies the first user message into maintenance (→ RL
interface: one-sentence persona + bash/str_replace_editor, context
stripped) or build (→ doer interface: hands-on persona + write-first
surface), never selects the competition band, and replaces the
spec-sentence+classify weak persona (measured anti-routing) with router-v2
few-shot (discrimination +2.6). Cross-validation: anchored-standard
achieves 98/99 on Project2 (Windows Pro) vs 91 for Standard; Mario
code-mode 10/10 vs anchored 6/10 on greenfield — the two interfaces are
complementary, and routing between them is the 50%-class gain the single
interfaces cannot reach.

## 1. Introduction

DeepSeek V4 Pro conditions strongly on the first-request interface: the
official `minimal` preset (one sentence, `complete: true`, persistent bash
+ str_replace_editor) reproduces the RL training interface, and community
evaluations measure 99/96 on maintenance under it vs 91 under Standard
(xiaobright Project2). But the same RL interface scores 6/10 on a
greenfield build task where the doer/code interface scores 10/10 (Mario).
"God/ghost duality" is therefore **interface-conditional behavior, not
capability variance** — and a router that selects the interface per task
family should dominate any single interface on mixed workloads.

This paper measures the structure that makes such routing possible (and
the trap that makes naive routing fail), then specifies a preset that
implements it.

## 2. Method

**Injection axis.** System prompt = RL sentence + `\n` +
`REACT.slice(0, round(x·len(REACT)))` for x∈[0,1] — a continuous proxy for
"how much doer conditioning is added to the RL interface". 21 points
(0.05 steps) × n=10 coarse (protocol B) plus [0, 0.35] at 0.01 steps × n=10
dense (protocol D). Tool surface: fixed 6-tool (bash/read/edit/write/glob/
grep). Order parameter ψ₁ = P(minimal-like) and continuous score
ψ₂ = (score+5)/10; planScore = we − letMe. Classifier lexicon identical to
the dsh-probe battery.

**Discrimination matrix (protocol E2).** 14 injection points ×
{maint, green} tasks × n=5 = 140 requests; discrimination = planScore(maint)
− planScore(green).

**Long-chain (protocol G).** 3-stage chains (build → fix → extend, black
hole task family) with synthetic tool results, 3 conditions × n=3.

**Interface restoration (protocol H, in progress).** RL interface (one
sentence + bash/str_replace_editor) at maxTokens 32K/256K vs Standard
surface — the Pro counterpart of the Flash measurement (100% action at
18–29K reasoning chars vs ~25% / 73–101K).

## 3. Results

### 3.1 Three-band structure (n=570)

| band | interval | ψ₁ | AIC model |
|---|---|---|---|
| RL interface | [0, 0.025] | 0.925 | three-band 668.7 |
| competition trap | [0.025, 0.455] | 0.464 | (vs logit 697.9) |
| doer | [0.455, 1] | 0.073 | winner |

xc = 0.192 [0.151, 0.229]; planScore slope −2.006 (t=−10.6) — continuous
order parameter is linear across the whole axis while the categorical one
is three-banded: **gradation at the style-mix level, transition at the
label level**.

### 3.2 The competition band anti-routes

E2: 9/12 points anti-route (−2.0..−10.6), 2 no-discrimination, 0
self-routing. Mechanism: maint planScore pinned +1.0..+1.4 by the spec
anchor regardless of x; green planScore fluctuates +0.6..+11.6 in the
competition noise — greenfield tasks become *more* plan-collective under
the competition band. **Any router that lands a session in [0.025, 0.455]
actively harms build tasks.**

### 3.3 Weak-domain discrimination (n=10)

router-v2 +2.6 > react +2.2 > w7 +2.0 > neutral +1.1 > w6c +0.2 > spec
−4.5. The spec-sentence+classify variant (w6c) is ineffective on Pro —
removed from router-pro. weak band = router-v2 few-shot.

### 3.4 Long-chain and triggers (G-pro)

Path commitment holds: build-stage lock survives into fix/extend (all
planScore ≤ 0); no in-chain lean. Okay-token trigger: neutral on Pro
(fix depth 137–280 vs baseline 152–1826) — Mid-Think's token trigger is a
Flash phenomenon. Depth on Pro is task-driven; the router should not
attempt depth modulation.

### 3.5 Interface restoration (H, partial)

Pro's 256K RL-interface requests are slow (no quick action like Flash's
19s) — Pro is a deep-thinker; the action-gain of interface restoration is
expected smaller than Flash's 4.3× but maintenance scores (anchored 98/99)
show the score-level gain is real.

## 4. router-pro: the preset

Specified from the measurements:

| first-message class | interface | persona | first-turn core | evidence |
|---|---|---|---|---|
| maintenance/fix | RL | one sentence | bash + str_replace_editor | anchored 98/99 |
| build/greenfield | doer | hands-on | read/write/edit (write-first) | Mario 10/10 |
| ambiguous | weak | router-v2 few-shot | bash + str_replace_editor | discrimination +2.6 |

Never: transition band [0.03, 0.455]; w6c; Okay trigger; output cap
(schema anchoring holds at 256K). Full Standard catalog after first
durable tool call. Implemented as `preset/router-pro/` (agent.cordis.yml +
router-bootstrap.mjs + router-core.mjs, zero deps).

## 5. Discussion

**The 50%-class gain.** Single-interface ceilings: RL interface ≈
maintenance 99 but build 6; doer ≈ build 10 but maintenance ~91. A router
with correct discrimination reaches ≈99 maintenance + ≈10 build — on a
mixed workload this is a +40–60% improvement over either single interface,
which is the class of gain the routing community measures on model pools
(RouteLLM-style) but which is often missed when routing is framed as
cost/latency rather than interface selection.

**The trap is the interesting part.** The competition band is not merely
useless — it is anti-routing: it *reverses* the task signal. This matches
the training-distribution-gap account (A2): intermediate prompt
configurations place the policy in the gap where attractor competition
dominates and task content is absorbed rather than used.

**Model specificity.** Flash: gradual order parameter, no transition band,
Okay-trigger effective, discrimination +4.6. Pro: sharp three-band, trap
band, Okay neutral, +2.6. The two models need different routers — router-pro
is the Pro instance; the Flash instance is the v0.2.0 standard/spec pair.

## 6. Limitations and open measurements

- Protocol H (RL interface on Pro, 32K/256K) is in progress; the score
  transfer to the black-hole build task is pending.
- The joint three-way evaluation (minimal vs standard vs router-pro on a
  mixed battery, both models) is the decisive missing measurement.
- E2 discrimination n=5; n=10 rerun would tighten the band edges.
- Single task family (black hole + repair chain); Project2/Mario numbers
  are community measurements (attributed).

## 7. References

1. DeepSeek-Harness official notes: minimal preset owns the RL composition
   (commit 86d5dd4); even-out-shipped-tool-rosters (same model, different
   surfaces, "a user-visible difference nobody had decided").
2. xiaobright/dsh-anchored-standard — Project2 98/99 (Windows V4 Pro);
   xiaobright/modeltest (V4.1b).
3. Mid-Think: Training-Free Intermediate-Budget Reasoning via Token-Level
   Triggers (ACL 2026 Findings).
4. Generalising LLM Routing using Past Performance Retrieval: A Few-Shot
   Router is Sufficient (EACL 2026 SRW).
5. EvolveRouter: Co-Evolving Routing and Prompt (arXiv 2604.05149).

*Data: routing-probe/results-{B,D,C,E2,G,H}-*.json; fit-final.mjs
(reproducible fits).*
